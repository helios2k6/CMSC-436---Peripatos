package project.android;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.jdom.input.*;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;

import project.android.HttpPostTask;
import project.android.R;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class AndroidProjectActivity extends Activity {
    /** Called when the activity is first created. */
	Document doc;
	Element root;
	String username;
	String password;
	String curClass;
	String curAssign;
	Double curLat;
	Double curLon;
	Element courseElement;
	Element assignmentElement;
	Element questionElement;
	Context context = this;
	MyLocationListener ll;
	LocationManager lm;
	Location bestReading;
	Button loginSubmit;
    Button loginClose;
	Namespace ns = Namespace.getNamespace("http://www.cs.umd.edu/class/fall2011/cmsc436/peripatos");
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		ll = new MyLocationListener();
		lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, ll);
		loginView();
		final EditText uName = (EditText) findViewById(R.id.unameText);
        final EditText pass = (EditText) findViewById(R.id.passText);
		loginSubmit.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				try {
					username = uName.getText().toString();
					password = pass.getText().toString();
				    // Construct data
					//XML to be sent to server
				    String data = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?><fetch_assignments xmlns=\"http://www.cs.umd.edu/class/fall2011/cmsc436/peripatos\"><user_credentials><username>"+username+"</username><password>"+password+"</password></user_credentials></fetch_assignments>"; 

				    // Send data
				    HttpPostTask task = new HttpPostTask();
			        task.execute("");
			        String result = "";
			        try {
						result = task.get();
						String xmlString = result;
						
						    SAXBuilder builder = new SAXBuilder();
						    doc = (Document) builder.build(new StringReader(xmlString));
						    root = doc.getRootElement();
						    Element status = root.getChild("error_code",ns);
					    if (status == null)
						{
						    classesView();
						}
						else{
							Toast.makeText(context,"Incorrect login information.",Toast.LENGTH_SHORT).show();
						}
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (ExecutionException e) {
						e.printStackTrace();
					}
			        
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}});
        loginClose.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				finish();
	            System.exit(0);
			}});
    }
    public void loginView(){
        loginSubmit = (Button) findViewById(R.id.loginSubmit);
        loginClose = (Button) findViewById(R.id.loginClose);
        
        
    }
    
    public void classesView(){
    	Element course;
    	setContentView(R.layout.classeslist);
    	final List<Element> courses = root.getChildren();
    	String[] spinner_array = new String[courses.size()];
    	int i=0;
    	while(i<courses.size()){
    		course = (Element) courses.get(i);
    		spinner_array[i]=course.getChildText("course_name", ns);
    		i++;
    	}
    	//spinner_array[0] = "TaDa";
    	//for each course element in courses, add course to drop down.
    	final Spinner spinner = (Spinner)findViewById(R.id.spinner1);
    	ArrayAdapter<?> adapter = new ArrayAdapter<Object>(this, android.R.layout.simple_dropdown_item_1line, spinner_array);
    	spinner.setAdapter(adapter);
    	Button classSubmit = (Button) findViewById(R.id.classSubmit);
    	Button classBack = (Button) findViewById(R.id.classBack);
    	classSubmit.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				curClass = spinner.getSelectedItem().toString();
				for(Element cur : courses){
					if(cur.getChildText("course_name", ns)==curClass)
					{
						courseElement = cur;
					}
				}
				assignmentsView();
			}});
    	classBack.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();
				System.exit(0);
			}
		});
    }
    public void assignmentsView(){
    	Element assignment;
    	setContentView(R.layout.assignments);
    	Element assign = courseElement.getChild("assignments",ns);
    	final List <Element> assignments = assign.getChildren();
    	String[] spinner_array = new String[assignments.size()];
    	int i=0;
    	while(i<assignments.size()){
    		assignment = (Element) assignments.get(i);
    		spinner_array[i]=assignment.getChildText("assignment_name", ns);
    		i++;
    	}
    	//spinner_array[0] = "TaDa";
    	//for each course element in courses, add course to drop down.
    	final Spinner spinner = (Spinner)findViewById(R.id.assignSpinner);
    	ArrayAdapter<?> adapter = new ArrayAdapter<Object>(this, android.R.layout.simple_dropdown_item_1line, spinner_array);
    	spinner.setAdapter(adapter);
   
    	Button assignSubmit = (Button) findViewById(R.id.assignSubmit);
    	Button assignBack = (Button) findViewById(R.id.assignBack);
    	assignSubmit.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				curAssign = spinner.getSelectedItem().toString();
				for(Element cur : assignments){
					if(cur.getChildText("assignment_name", ns)==curAssign)
					{
						assignmentElement = cur;
					}
				}
				questionListView();
			}
    	});
    	assignBack.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				classesView();
			}
    		
    	});
    }
    public void questionListView(){
    	LinearLayout questionLayout = new LinearLayout(context);
    	questionLayout.setOrientation(1);
    	Element quest = assignmentElement.getChild("questions",ns);
    	final List <Element> questions = quest.getChildren();
    	int i = 0;
    	while(i<questions.size()){
    		
    		Element curQuestion = questions.get(i);
    		LinearLayout lLayout = new LinearLayout(this);
    		LinearLayout lLayout2 = new LinearLayout(this);
    		LinearLayout lLayout3 = new LinearLayout(this);
    		CheckBox check = new CheckBox(this);
    		TextView label = new TextView(this);
    		TextView lat = new TextView(this);
    		TextView lon = new TextView(this);
    		Element geolocation = curQuestion.getChild("geolocation",ns);
    		
    		label.setText(curQuestion.getChildText("question_title",ns));
   
    		lat.setText("Latitude: " + geolocation.getChildText("latitude",ns));
    		lon.setText("Longitude: " + geolocation.getChildText("longitude",ns));
    		check.setId(i);
    		//MATCH_PARENT = -1 WRAP_CONTENT = -2
    		LinearLayout.LayoutParams llparams = new LinearLayout.LayoutParams(-1,-2,(float).09);
    		LinearLayout.LayoutParams llparams2 = new LinearLayout.LayoutParams(-2,-1,(float).56);
    		LinearLayout.LayoutParams llparams3 = new LinearLayout.LayoutParams(160,-1,(float).28);
    		LinearLayout.LayoutParams checkparams = new LinearLayout.LayoutParams(60,-2);
    		LinearLayout.LayoutParams labelparams = new LinearLayout.LayoutParams(-2,-2);
    		LinearLayout.LayoutParams latparams = new LinearLayout.LayoutParams(-2,-2);
    		LinearLayout.LayoutParams lonparams = new LinearLayout.LayoutParams(-2,-2);
    		check.setLayoutParams(checkparams);
    		label.setLayoutParams(labelparams);
    		lat.setLayoutParams(latparams);
    		lon.setLayoutParams(lonparams);
    		lLayout.setLayoutParams(llparams);
    		lLayout2.setLayoutParams(llparams2);
    		lLayout2.setOrientation(1);
    		lLayout3.setLayoutParams(llparams3);
    		lLayout3.setOrientation(1);
    		lLayout2.addView(label);
    		lLayout3.addView(lat);
    		lLayout3.addView(lon);
    		lLayout.addView(check);
    		lLayout.addView(lLayout2);
    		lLayout.addView(lLayout3);
    		questionLayout.addView(lLayout);
    		i++;
    	}
    	LinearLayout layoutButtons = new LinearLayout(this);
    	LinearLayout.LayoutParams buttonlayoutparams = new LinearLayout.LayoutParams(-2,-2);
    	LinearLayout.LayoutParams buttonparams = new LinearLayout.LayoutParams(175,85);
    	LinearLayout.LayoutParams buttonparams2 = new LinearLayout.LayoutParams(100,85);
    	layoutButtons.setLayoutParams(buttonlayoutparams);
    	Button checkLoc = new Button(this);
    	checkLoc.setText("Get Coordinates");
    	
    	checkLoc.setLayoutParams(buttonparams);
    	checkLoc.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v) {
				if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){
					lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, ll);
					Location loc = ((MyLocationListener) ll).getLocation(context);
					curLat = loc.getLatitude();
					curLon = loc.getLongitude();
					Executors.newScheduledThreadPool(1).schedule(
							new Runnable(){
								public void run(){
									lm.removeUpdates(ll);
								}},10000,TimeUnit.MILLISECONDS);
					
				}
				else{
					Toast.makeText(context,"GPS not enabled",Toast.LENGTH_SHORT).show();
				}
				
			}
    	});
    	layoutButtons.addView(checkLoc);
    	Button view = new Button(this);
    	view.setText("View selected question");
    	view.setLayoutParams(buttonparams);
    	view.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				for(int x=0;x<questions.size();x++){
					CheckBox curCheck = (CheckBox) findViewById(x);
					if(curCheck.isChecked()){
						questionElement = questions.get(x);
						Double qLat;
						Double qLon;
						Double latit = curLat;
						Double longi = curLon;
						String latStore = questionElement.getChild("geolocation",ns).getChildText("latitude",ns);
						String lonStore = questionElement.getChild("geolocation",ns).getChildText("longitude",ns);
					    qLat = new Double(latStore);
					    qLon = new Double(lonStore);
						if(latit.compareTo(qLat)==0.0 && longi.compareTo(qLon) == 0.0){
							questionDetailsView();
							break;
						}
						else{
							Toast.makeText(context,"Can't view that question. You are not at the correct location. Try using the Get Coordinates button.",Toast.LENGTH_LONG).show();
						}
						
					}
				}
				
			}
		});
    	Button back = new Button(this);
    	back.setText("Back");
    	buttonparams2.setMargins(0,11,0,0);
    	back.setLayoutParams(buttonparams2);
    	back.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				assignmentsView();
			}
    		
    	});
    	layoutButtons.addView(view);
    	layoutButtons.addView(back);
    	questionLayout.addView(layoutButtons);
    	setContentView(questionLayout);
    }



    public void questionDetailsView(){
    	setContentView(R.layout.questionsubmit);
    	TextView title = (TextView) findViewById(R.id.qTitle);
    	TextView body = (TextView) findViewById(R.id.qBody);
    	TextView answerLabel = (TextView) findViewById(R.id.qAnswerLabel);
    	final EditText answer = (EditText) findViewById(R.id.qAnswerText);
    	Button submit = (Button) findViewById(R.id.qSubmit);
    	Button back = (Button) findViewById(R.id.qBack);
    	String titleText = questionElement.getChildText("question_title",ns);
    	title.setText(titleText);
    	body.setText(questionElement.getChildText("question_body",ns));
    	answerLabel.setText("Answer to " + titleText +":");
    	submit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				final String answerText = answer.getText().toString();
				String data = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?><fetch_assignments xmlns=\"http://www.cs.umd.edu/class/fall2011/cmsc436/peripatos\"><user_credentials><username>"+username+"</username><password>"+password+"</password></user_credentials></fetch_assignments>"; 

			    // Send data
			    HttpPostAnswer task = new HttpPostAnswer();
		        task.execute("");
		        String result = "";
		        try {
		        	result = task.get();
					String xmlString = result;
					    SAXBuilder builder = new SAXBuilder();
					    doc = (Document) builder.build(new StringReader(xmlString));
					    root = doc.getRootElement();
					    String status = root.getChildText("status",ns);
				    if (status.equalsIgnoreCase("Okay"))
					{
					    classesView();
					}
					else{
						Toast.makeText(context,"Incorrect login information.",Toast.LENGTH_SHORT).show();
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (ExecutionException e) {
					e.printStackTrace();
				} catch (JDOMException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
    	back.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				questionListView();
			}
    		
    	});
    }
}
