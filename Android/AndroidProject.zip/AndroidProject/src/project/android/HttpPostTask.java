package project.android;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Scanner;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.protocol.HTTP;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;

public class HttpPostTask extends AsyncTask<String, Integer, String>{

	private static final String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" +
			"<fetch_assignments xmlns=\"http://www.cs.umd.edu/class/fall2011/cmsc436/peripatos\">" +
			"<user_credentials><username>" + username +"</username><password>"+ password +"</password></user_credentials></fetch_assignments>";

	@Override
	protected String doInBackground(String... arg0) {
		AndroidHttpClient client = AndroidHttpClient.newInstance("");
		HttpPost post = new HttpPost("http://vestigial.cs.umd.edu:8080/peripatos-1.0-SNAPSHOT/peripatos/android/request");

		try {
			StringEntity entity = new StringEntity(xmlString, HTTP.UTF_8);
			post.setEntity(entity);
			
			HttpResponse response = client.execute(post);
			
			HttpEntity responseEntity = response.getEntity();
			
			InputStream streamResponse = responseEntity.getContent();
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(streamResponse));
			
			Scanner scanner = new Scanner(reader);
			
			StringBuffer bufferedString = new StringBuffer();
			
			while(scanner.hasNext()){
				bufferedString.append(scanner.next());
			}
			
			String fullProcess = bufferedString.toString();
			
			return URLDecoder.decode(fullProcess);
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void onPostExecute(String... result){
		
	}

}
